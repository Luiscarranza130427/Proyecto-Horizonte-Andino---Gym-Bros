<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
public function up(): void
{
    Schema::table('evaluaciones_fisicas', function (Blueprint $table) {

        $table->foreign('id_usuarios')
            ->references('id')
            ->on('usuarios')
            ->onDelete('cascade');

    });
}

    public function down(): void
    {
        Schema::table('evaluaciones_fisicas', function (Blueprint $table) {

            $table->dropForeign(['id_usuarios']);

            $table->dropColumn('id_usuarios');
        });
    }
};