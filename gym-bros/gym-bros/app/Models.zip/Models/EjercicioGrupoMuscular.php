<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class EjercicioGrupoMuscular extends Model
{
    use HasFactory;
    protected $table = 'ejercicios_grupo_muscular';
    protected $fillable = [
        'id_ejercicios',
        
    ];
    public function ejercicio()
    {
        return $this->belongsTo(Ejercicio::class,'id_ejercicios');
    }

}
