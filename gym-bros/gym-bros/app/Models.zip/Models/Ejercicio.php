<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;


class Ejercicio extends Model
{
    use HasFactory;
    protected $table = 'ejercicios';
    protected $fillable = [
        'nombre',
        'descripcion',
        'instrucciones',
        'nivel',
        'equipamiento',
        'estado',
        'enlace_video',
        'imagen_ejercicio',
        'id_grupos_musculares',
        'id_empresas'
    ];

    public function grupomuscular()
    {
        return $this->belongsTo(GrupoMuscular::class, 'id_grupos_musculares');
    }

    public function empresa()
    {
        return $this->belongsTo(Empresa::class, 'id_empresas');
    }
}
