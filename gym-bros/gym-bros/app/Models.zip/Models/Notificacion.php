<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Notificacion extends Model
{
    use HasFactory;
    protected $table = 'notificaciones';
    protected $fillable = [
        'id_empresas',
        'id_usuarios',
        'tipo',
        'titulo',
        'mensaje',
        'fecha_envio',
        'leida',
        'enviada'
    ];

    public function empresa()
    {
        return $this->belongsTo(Empresa::class,'id_empresas');
    }

    public function ususario()
    {
        return $this->belongsTo(Usuario::class,'id_usuarios');
    }
}
