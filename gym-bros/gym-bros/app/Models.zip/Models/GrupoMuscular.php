<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class GrupoMuscular extends Model
{
    use HasFactory;
    protected $table = 'grupos_musculares';
    protected $fillable = [
        'descripcion',
        'estado',
        'tipo'
    ];
}
