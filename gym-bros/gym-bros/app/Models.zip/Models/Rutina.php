<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Rutina extends Model
{
    use HasFactory;
    protected $table = 'rutinas';
    protected $fillable = [
        'nombre',
        'descripcion',
        'objetivo',
        'dias_semana',
        'duracion_estimada',
        'fecha_inicio',
        'fecha_fin',
        'estado',
        'id_usuarios'
    ];

    public function ususario()
    {
        return $this->belongsTo(Usuario::class, 'id_usuarios');
    }
}
