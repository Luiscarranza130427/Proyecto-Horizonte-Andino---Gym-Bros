<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Usuario extends Model
{
    use HasFactory;
    protected $table = 'usuarios';
    protected $fillable = [
        'nombre',
        'apellidos',
        'correo',
        'password_hash',
        'tipo_documento',
        'numero_documento',
        'telefono',
        'direccion',
        'foto_perfil',
        'fecha_registro',
        'fecha_nacimiento',
        'asistencia_semanal',
        'tipo_usuario',
        'estado',
        'id_empresas'
    ];

    protected $hidden =[
        'password_hash',
    ];

    public function empresa()
    {
        return $this->belongsTo(Empresa::class,'id_empresas');
    }
}
