<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class EvaluacionFisica extends Model
{
    use HasFactory;
    protected $table = 'evaluaciones_fisicas';
    protected $fillable = [
        'nivel_experiencia',
        'actividad_diaria',
        'objetivo',
        'edad',
        'peso',
        'altura',
        'porcentaje_grasa',
        'masa_muscular',
        'cintura',
        'pecho',
        'brazo',
        'muslo',
        'cadera',
        'dias_semana',
        'eleccion_dias',
        'tiempo_sesion_min',
        'restricciones',
        'fecha_evaluacion'

    ];
}
